﻿using StokTakip.Data;
using StokTakip.Helpers;
using StokTakip.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StokTakip.Services
{
    public class PersonelServices
    {
        
        private readonly PersonelRepository _repository;
        public PersonelServices(PersonelRepository repository) => _repository = repository;

        public Personel? GetByEposta(string eposta) => _repository.GetByEposta(eposta);

        public Personel? GetBySifre(string sifre) => _repository.GetBySifre(sifre);

        public string? GetSistemYetkiliSifre() => _repository.GetSistemYetkiliSifre();

        public void Create(PersonelDto dto)
        {
            var entity = new Personel()
            {
                Ad = dto.Ad,
                Soyad = dto.Soyad,
                Gorev = dto.Gorev,
                Telefon = dto.Telefon,
                Eposta = dto.Eposta,
                Sifre = dto.Sifre, // normal personel şifresi
                Rol = dto.Rol,
                YetkiliSifre = dto.Rol && !string.IsNullOrWhiteSpace(dto.YetkiliSifre)
                    ? HashHelper.HashSha256(dto.YetkiliSifre) // hashleyip kaydet
                    : null
            };
            _repository.Add(entity);
        }

        //// Yetkili şifreyi doğrulama 10.09.2025
        public bool VerifyYetkiliSifre(string girilenSifre)
        {
            var sistemSifreHash = _repository.GetSistemYetkiliSifre();

            if (string.IsNullOrWhiteSpace(sistemSifreHash))
                return true; // İlk yetkili için

            // Hash yardımıyla karşılaştır
            return HashHelper.VerifyHash(girilenSifre.Trim(), sistemSifreHash);
        }




    }
}
