﻿using StokTakip.Models;
using StokTakip.StokTakip.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StokTakip.Data
{
    public class PersonelRepository
    {
        private readonly StokTakipContext _context;
        public PersonelRepository(StokTakipContext context) => _context = context;

        public Personel? GetByEposta(string eposta) =>
            _context.Personels.FirstOrDefault(p => p.Eposta == eposta);

        public Personel? GetBySifre(string sifre) =>
            _context.Personels.FirstOrDefault(p => p.Sifre == sifre);

        public string? GetSistemYetkiliSifre() =>
            _context.Personels.FirstOrDefault(p => p.Rol)?.YetkiliSifre;

        public void Add(Personel p)
        {
            _context.Add(p);
            _context.SaveChanges();
        }

        public void SifirlaYetkiliSifre()
        {
            var yetkili = _context.Personels.FirstOrDefault(p => p.Rol);
            if (yetkili != null)
            {
                yetkili.YetkiliSifre = null;
                _context.SaveChanges();
            }
        }
    }
}
