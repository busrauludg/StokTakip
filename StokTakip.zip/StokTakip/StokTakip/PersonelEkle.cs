﻿using Humanizer;
using StokTakip.Data;
using StokTakip.Helpers;
using StokTakip.Services;
using StokTakip.StokTakip.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StokTakip
{
    public partial class PersonelEkle : Form
    {
        private string? _yetkiliSifrePlain = null;
        

        private readonly PersonelServices _personelService;
        public PersonelEkle()
        {
            InitializeComponent();
            // Form açılır açılmaz yetkili şifre alanını gizle
            tBYetkiliSifre.Visible = false;
            lblYetkiliSifre.Visible = false;

            // Service örneği
            _personelService = new PersonelServices(new PersonelRepository(new StokTakipContext()));

        }

        private void rBPrsYetkili_CheckedChanged(object sender, EventArgs e)
        {
            tBYetkiliSifre.Visible = rBPrsYetkili.Checked;
            lblYetkiliSifre.Visible = rBPrsYetkili.Checked;

        }
        // Yetkili şifreyi formdan al
        private void lblYetkiliSifre_Click(object sender, EventArgs e)
        {
            if (!rBPrsYetkili.Checked)
            {
                MessageBox.Show("Önce Rol: Yetkili seçin.");
                return;
            }

            using var dlg = new YetkiliSifreForm();
            if (dlg.ShowDialog() == DialogResult.OK)
                _yetkiliSifrePlain = dlg.Sifre;
        }
        private void btnPersonelKayit_Click(object sender, EventArgs e)
        {
            // DTO için temel bilgileri al
            var dto = new PersonelDto
            {
                Ad = tBPrsAdi.Text,
                Soyad = tBPrsSoyadi.Text,
                Gorev = tBPrsGorev.Text,
                Telefon = tBPrsTelNo.Text,
                Eposta = tBPrsEposta.Text,
                Sifre = tBPrsSifre.Text,
                Rol = rBPrsYetkili.Checked
            };

            // E-posta kontrolü
            if (_personelService.GetByEposta(dto.Eposta!) != null)
            {
                MessageBox.Show("Bu e-posta zaten kayıtlı.");
                return;
            }

            // Şifre benzersiz kontrolü
            if (_personelService.GetBySifre(dto.Sifre) != null)
            {
                MessageBox.Show("Bu şifre zaten kullanımda.");
                return;
            }

            // Yetkili ise şifre kontrolü
            if (rBPrsYetkili.Checked)
            {
                if (string.IsNullOrWhiteSpace(tBYetkiliSifre.Text))
                {
                    MessageBox.Show("Yetkili şifresi boş olamaz!");
                    return;
                }

                var girilenSifre = tBYetkiliSifre.Text.Trim();
                var sistemSifreHash = _personelService.GetSistemYetkiliSifre();

                // Eğer zaten bir yetkili şifresi var ise doğrula
                if (!string.IsNullOrWhiteSpace(sistemSifreHash))
                {
                    if (!_personelService.VerifyYetkiliSifre(girilenSifre))
                    {
                        MessageBox.Show("Yetkili şifresi hatalı!");
                        return;
                    }
                }

                // DTO’ya yetkili şifreyi ekle (hashlenmiş olarak kaydedilecek)
                dto.YetkiliSifre = girilenSifre;
            }

            // Kayıt işlemi
            _personelService.Create(dto);
            MessageBox.Show("Personel başarıyla eklendi.");
        }



        private void tBYetkiliSifre_TextChanged(object sender, EventArgs e)
        {
            // Yetkili şifre eşleşme kontrolü
            
        }
    }
}
